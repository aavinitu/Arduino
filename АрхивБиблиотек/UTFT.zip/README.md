UTFT
===========

Библиотека для Arduino, позволяющая выводить текст и красочную графику на TFT-дисплеи с разрешением [240x320](http://amperka.ru/product/tft-color-display-320x240) и [480x320](http://amperka.ru/product/tft-color-display-480x320) с помощью Arduino без необходимости задумываться о деталях протокола.

Установка
=========

Скачайте последний релиз библиотеки:

<a class="btn btn-sm btn-primary" href="https://github.com/amperka/utft/releases/download/utft.zip">Скачать библиотеку UTFT </a>

В Arduino IDE выберите пункт меню «Скетч» → «Импортировать библиотеку» →
«Добавить библиотеку…». В появившемся окне выберите скачаный архив с
библиотекой. Установка завершена.
